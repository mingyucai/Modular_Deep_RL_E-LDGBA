import gym
import ra_gym
import math
import numpy as np

from get_dynamics import get_dynamics
from ECBF import ECBF_control, continuous_ECBF, continuous_ECBF_version1

env = gym.make('RAEnv-v0')
episodes = 10
theta, theta_dot= [], []
position, position_dot = [], []
infeasible = []
torque = []


for i in range(episodes):
    rewards = 0
    state = env.reset()
    done = False
    while not done:
        action = env.action_space.sample()

        f, g, x = get_dynamics(state, action)
        u_cbf, slack = continuous_ECBF_version1(x, action, f, g)

        print('action', action, 'CFB: ', u_cbf, 'slack', slack)


        action = u_cbf

        next_state, reward, done, _ = env.step(action)
        rewards += reward
        env.render()

        state = next_state
        theta.append(state[2])
        theta_dot.append(state[3])
        position.append(state[0])
        position_dot.append(state[1])
        torque.append(action)
        if slack >= 0.01:
            infeasible.append(slack)
env.close()

res = []
for i in theta:
    if abs(i) > 12 * 2 * math.pi / 360:
        res.append(i)
print(max(theta, key=abs))
print('violation_number: ', len(res), 'infeasible_number: ', len(infeasible))


print('max_theta_dot: ', max(theta_dot, key=abs), 'max_x_dot', max(position_dot, key=abs))

print('max_action', max(torque, key=abs))

res = []
for i in position:
    if abs(i) > 2.4:
        res.append(i)
print(max(theta, key=abs))
print('violation_number: ', len(res), 'infeasible_number: ', len(infeasible))