import math
import gym
from gym import spaces, logger
from gym.utils import seeding
import numpy as np
from os import path


class RAEnv(gym.Env):
	metadata = {
		'render.modes': ['rgb_array'],
		'video.frames_per_second': 50
	}
	def __init__(self):
		self.gravity = 9.8
		self.masscart = 1.0
		self.masspole = 0.1
		self.total_mass = (self.masspole + self.masscart)
		self.length = 0.5  # actually half the pole's length
		self.polemass_length = (self.masspole * self.length)
		#self.force_mag = 5.0
		self.tau = 0.02  # seconds between state updates
		self.min_action = -20.0
		self.max_action = 20.0

		self.unsafe = False

		# Angle at which to fail the episode
		self.theta_threshold_radians = 12 * 2 * math.pi / 360
		self.x_threshold = 2.8

		# Angle limit set to 2 * theta_threshold_radians so failing observation
		# is still within bounds
		high = np.array([
			self.x_threshold * 2,
			np.finfo(np.float32).max,
			self.theta_threshold_radians * 2,
			np.finfo(np.float32).max,1,1])

		self.action_space = spaces.Box(
			low=self.min_action,
			high=self.max_action,
			shape=(1,)
		)
		self.observation_space = spaces.Box(-high, high)

		self.seed()
		self.viewer = None
		self.state = None

		self.steps_beyond_done = None
		self._max_episode_steps = 500

	def seed(self, seed=None):
		self.np_random, seed = seeding.np_random(seed)
		return [seed]

	def stepPhysics(self, force):
		x, x_dot, theta, theta_dot = self.state[0:4]
		costheta = math.cos(theta)
		sintheta = math.sin(theta)
		temp = (force + self.polemass_length * theta_dot * theta_dot * sintheta) / self.total_mass
		thetaacc = (self.gravity * sintheta - costheta * temp) / \
				   (self.length * (4.0 / 3.0 - self.masspole * costheta * costheta / self.total_mass))
		xacc = temp - self.polemass_length * thetaacc * costheta / self.total_mass
		x = x + self.tau * x_dot
		x_dot = x_dot + self.tau * xacc
		theta = theta + self.tau * theta_dot
		theta_dot = theta_dot + self.tau * thetaacc
		return (x, x_dot, theta, theta_dot)

	def step(self, action):
		# assert self.action_space.contains(action), \
		# 	"%r (%s) invalid" % (action, type(action))

		self.steps +=1
		reward = 0
		force = float(action)
		state = self.stepPhysics(force)
		x, x_dot, theta, theta_dot = state
		done = x < -self.x_threshold \
			   or x > self.x_threshold \
			   or theta < -self.theta_threshold_radians \
			   or theta > self.theta_threshold_radians
		done = bool(done)

		unsafe = x < -self.x_threshold \
			   or x > self.x_threshold \
			   or theta < -self.theta_threshold_radians \
			   or theta > self.theta_threshold_radians

		# if unsafe:
		# 	reward = -50*abs(theta-self.theta_threshold_radians) - 50*abs(x-self.x_threshold) #- 10 * (abs(x-self.x_threshold) + 10*abs(theta-self.theta_threshold_radians))

		if done:
			if x < -self.x_threshold or x > self.x_threshold:
				reward = - 50 * abs(x - self.x_threshold)
			elif theta < -self.theta_threshold_radians or theta > self.theta_threshold_radians:
				reward += -200 * abs(theta - self.theta_threshold_radians)
			reward = -50 + reward
			state = np.array(state)
			self.state = np.append(state, [self.region1_crossed, self.region2_crossed])
			return np.array(self.state), reward, done, {}


		region1 = x>=0.96 and x<=1.44
		region2 = x>=-1.44 and x<=-0.96


		if region1:
			if not self.region1_crossed and self.region1_count<=10:
				self.region1_count+= 1
				reward = 10
			elif self.region1_count >10:
				self.region1_crossed = True

		if region2 and self.region1_crossed:
			if not self.region2_crossed and self.region2_count<=10:
				self.region2_count += 1
				reward = 10
				print('done once')
			elif self.region2_count>10:
				self.region2_crossed = True

		if self.region1_crossed and self.region2_crossed:
			#done = True
			self.region1_crossed = False
			self.region2_crossed = False
			self.region1_count = 0
			self.region2_count = 0


		if self.steps >= self._max_episode_steps:
			done = True
			state = np.array(state)
			self.state = np.append(state, [self.region1_crossed, self.region2_crossed])
			return np.array(self.state), reward, done, {}


		state = np.array(state)
		self.state = np.append(state,[self.region1_crossed, self.region2_crossed])

		return np.array(self.state), reward, done, {}

	def reset(self):
		self.steps_beyond_done = None
		self.steps = 0
		self.region1_crossed = False
		self.region2_crossed = False
		self.region1_count = 0
		self.region2_count = 0
		self.state = np.array([0,0,0,0,self.region1_crossed,self.region2_crossed])
		return np.array(self.state)

	def render(self, mode='human'):
		screen_width = 600
		screen_height = 400

		world_width = self.x_threshold * 2
		scale = screen_width / world_width
		carty = 100  # TOP OF CART
		polewidth = 10.0
		polelen = scale * 1.0
		cartwidth = 50.0
		cartheight = 30.0

		if self.viewer is None:
			from gym.envs.classic_control import rendering
			self.viewer = rendering.Viewer(screen_width, screen_height)
			# Label
			l, r, t, b = -60 / 2, 60 / 2, 60 / 2, -60 / 2
			box2 = rendering.FilledPolygon([(l, b), (l, t), (r, t), (r, b)])
			box2.set_color(1, 1, 0.3)
			box2_carttrans = rendering.Transform(translation=(450, 100))
			box2.add_attr(box2_carttrans)
			self.viewer.add_geom(box2)
			l, r, t, b = -60 / 2, 60 / 2, 60 / 2, -60 / 2
			box1 = rendering.FilledPolygon([(l, b), (l, t), (r, t), (r, b)])
			box1.set_color(0.5,0.95,0.5)
			box1_carttrans = rendering.Transform(translation=(150,100))
			box1.add_attr(box1_carttrans)
			self.viewer.add_geom(box1)

			l, r, t, b = -10 / 2, 10 / 2, 150 / 2, -150 / 2
			line1 = rendering.FilledPolygon([(l, b), (l, t), (r, t), (r, b)])
			line1.set_color(1, 0, 0)
			line1_carttrans = rendering.Transform(translation=(20, 100))
			line1.add_attr(line1_carttrans)
			self.viewer.add_geom(line1)

			l, r, t, b = -10 / 2, 10 / 2, 150 / 2, -150 / 2
			line2 = rendering.FilledPolygon([(l, b), (l, t), (r, t), (r, b)])
			line2.set_color(1, 0, 0)
			line2_carttrans = rendering.Transform(translation=(580, 100))
			line2.add_attr(line2_carttrans)
			self.viewer.add_geom(line2)
#cart-pole

			l, r, t, b = -cartwidth / 2, cartwidth / 2, cartheight / 2, -cartheight / 2
			axleoffset = cartheight / 4.0
			cart = rendering.FilledPolygon([(l, b), (l, t), (r, t), (r, b)])
			self.carttrans = rendering.Transform()
			cart.add_attr(self.carttrans)
			self.viewer.add_geom(cart)
			l, r, t, b = -polewidth / 2, polewidth / 2, polelen - polewidth / 2, -polewidth / 2
			pole = rendering.FilledPolygon([(l, b), (l, t), (r, t), (r, b)])
			pole.set_color(.8, .6, .4)
			self.poletrans = rendering.Transform(translation=(0, axleoffset))
			pole.add_attr(self.poletrans)
			pole.add_attr(self.carttrans)
			self.viewer.add_geom(pole)
			self.axle = rendering.make_circle(polewidth / 2)
			self.axle.add_attr(self.poletrans)
			self.axle.add_attr(self.carttrans)
			self.axle.set_color(.5, .5, .8)
			self.viewer.add_geom(self.axle)
			self.track = rendering.Line((0, carty), (screen_width, carty))
			self.track.set_color(0, 0, 0)
			self.viewer.add_geom(self.track)

		if self.state is None:
			return None

		x = self.state
		cartx = x[0] * scale + screen_width / 2.0  # MIDDLE OF CART
		self.carttrans.set_translation(cartx, carty)
		self.poletrans.set_rotation(-x[2])

		return self.viewer.render(return_rgb_array=(mode == 'rgb_array'))

	def close(self):
		if self.viewer:
			self.viewer.close()

# class RAEnv(gym.Env):
#     metadata = {
#         'render.modes': ['human', 'rgb_array'],
#         'video.frames_per_second': 30
#     }
#
#     def __init__(self, g=10.0):
#         self.max_speed = 30
#         self.max_torque = 15.
#         self.dt = .05
#         self.g = g
#         self.m = 1.
#         self.l = 1.
#         self.viewer = None
#
#         high = np.array([1., 1., self.max_speed], dtype=np.float32)
#         self.action_space = spaces.Box(
#             low=-self.max_torque,
#             high=self.max_torque, shape=(1,),
#             dtype=np.float32
#         )
#         self.observation_space = spaces.Box(
#             low=-high,
#             high=high,
#             dtype=np.float32
#         )
#
#         self.seed()
#
#     def seed(self, seed=None):
#         self.np_random, seed = seeding.np_random(seed)
#         return [seed]
#
#     def step(self, u):
#         th, thdot = self.state  # th := theta
#
#         g = self.g
#         m = self.m
#         l = self.l
#         dt = self.dt
#
#         u = np.clip(u, -self.max_torque, self.max_torque)[0]
#         self.last_u = u  # for rendering
#         costs = angle_normalize(th) ** 2 + .1 * thdot ** 2 + .001 * (u ** 2)
#
#         newthdot = thdot + (-3 * g / (2 * l) * np.sin(th + np.pi) + 3. / (m * l ** 2) * u) * dt
#         newth = th + newthdot * dt
#         newthdot = np.clip(newthdot, -self.max_speed, self.max_speed)
#
#         self.state = np.array([newth, newthdot])
#         return self._get_obs(), -costs, False, {}
#
#     def reset(self):
#         high = np.array([np.pi, 1])
#         self.state = self.np_random.uniform(low=-high, high=high)
#         self.last_u = None
#         return self._get_obs()
#
#     def _get_obs(self):
#         theta, thetadot = self.state
#         return np.array([np.cos(theta), np.sin(theta), thetadot])
#
#     def render(self, mode='human'):
#         if self.viewer is None:
#             from gym.envs.classic_control import rendering
#             self.viewer = rendering.Viewer(500, 500)
#             self.viewer.set_bounds(-2.2, 2.2, -2.2, 2.2)
#             rod = rendering.make_capsule(1, .2)
#             rod.set_color(.8, .3, .3)
#             self.pole_transform = rendering.Transform()
#             rod.add_attr(self.pole_transform)
#             self.viewer.add_geom(rod)
#             axle = rendering.make_circle(.05)
#             axle.set_color(0, 0, 0)
#             self.viewer.add_geom(axle)
#             fname = path.join(path.dirname(__file__), "assets/clockwise.png")
#             self.img = rendering.Image(fname, 1., 1.)
#             self.imgtrans = rendering.Transform()
#             self.img.add_attr(self.imgtrans)
#
#         self.viewer.add_onetime(self.img)
#         self.pole_transform.set_rotation(self.state[0] + np.pi / 2)
#         if self.last_u:
#             self.imgtrans.scale = (-self.last_u / 2, np.abs(self.last_u) / 2)
#
#         return self.viewer.render(return_rgb_array=mode == 'rgb_array')
#
#     def close(self):
#         if self.viewer:
#             self.viewer.close()
#             self.viewer = None
#
#
# def angle_normalize(x):
#     return (((x+np.pi) % (2*np.pi)) - np.pi)