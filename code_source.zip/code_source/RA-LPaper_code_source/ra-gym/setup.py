from setuptools import setup
setup(name='ra_gym',
    version='0.1',
    install_requires=['gym', 'numpy']
)