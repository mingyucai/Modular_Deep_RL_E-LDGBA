from moviepy.editor import *

clip = (VideoFileClip("input.mp4"))
clip.write_gif("output.gif")