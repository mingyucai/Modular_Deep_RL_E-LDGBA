from matplotlib import pyplot as plt
import numpy as np

x = np.linspace(0, 30, 30)
y = np.sin(x/6*np.pi)
error = np.random.normal(0.1, 0.02, size=y.shape)
y += np.random.normal(0, 0.1, size=y.shape)

b=np.std(x)
print(x.shape)

a = [1,2,3,4,5,6,10]
a.append(10)
a = np.array(a)
a = np.append(a, np.mean(x))
print(a)
print(a.shape)

y = np.arange(0,10,1)
print(y.shape)



